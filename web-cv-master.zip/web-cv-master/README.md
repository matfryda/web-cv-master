## Resume
Simple web resume made in HTML/CSS - matbylin@gmail.com

## GitHub Pages
Check my resume on github pages : [MatBylinWebResume](https://matbylin.github.io/web-cv/)

## Credits
* Background image from [unsplash.com/@lifeofizaac_](https://unsplash.com/@lifeofizaac_/)
* Face avatar from [face.co](https://face.co/)
